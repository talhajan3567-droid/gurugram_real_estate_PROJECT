# 03 — Insights & Visualization

Create publication-ready charts and summarize:
- Top locations by average price
- Affordable locations
- Price per square foot
- Area vs price
- Bedrooms vs price
- Important anomalies

Save final charts in `reports/figures/`.
