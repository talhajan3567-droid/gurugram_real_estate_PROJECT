# 02 — Exploratory Data Analysis

Suggested analysis:
- Descriptive statistics
- Price distribution
- Area distribution
- Location frequency
- Price by locality
- Bedrooms and bathrooms
- Correlation analysis
- Outlier analysis
