# 01 — Data Loading & Cleaning

Suggested steps:
1. Load the raw CSV with Pandas.
2. Inspect shape, columns, dtypes, and missing values.
3. Remove duplicates.
4. Standardize column names.
5. Convert numeric columns.
6. Handle missing values using documented rules.
7. Save the cleaned dataset to `data/processed/`.
