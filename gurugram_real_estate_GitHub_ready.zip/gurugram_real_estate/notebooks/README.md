# Notebooks

Run the notebooks in this order:

1. `01_data_loading_and_cleaning.ipynb`
2. `02_exploratory_data_analysis.ipynb`
3. `03_insights_and_visualization.ipynb`

The notebooks are intentionally separated so that data preparation, exploration, and communication of insights remain easy to follow.
