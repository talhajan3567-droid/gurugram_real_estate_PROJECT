"""Reusable data-cleaning helpers for the Gurugram real-estate project."""

import pandas as pd


def basic_cleaning(df: pd.DataFrame) -> pd.DataFrame:
    """Return a cleaned copy with normalized column names and duplicates removed."""
    cleaned = df.copy()
    cleaned.columns = (
        cleaned.columns.astype(str)
        .str.strip()
        .str.lower()
        .str.replace(" ", "_", regex=False)
    )
    cleaned = cleaned.drop_duplicates().reset_index(drop=True)
    return cleaned
