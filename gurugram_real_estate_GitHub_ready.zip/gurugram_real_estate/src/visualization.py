"""Visualization helpers for the project."""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd


def plot_price_distribution(
    df: pd.DataFrame,
    price_col: str = "price",
    output_path: str | None = None,
):
    """Plot the distribution of property prices."""
    values = pd.to_numeric(df[price_col], errors="coerce").dropna()
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.histplot(values, kde=True, ax=ax)
    ax.set_title("Gurugram Property Price Distribution")
    ax.set_xlabel("Price")
    ax.set_ylabel("Number of Properties")
    fig.tight_layout()

    if output_path:
        fig.savefig(output_path, dpi=300, bbox_inches="tight")
    return fig, ax
