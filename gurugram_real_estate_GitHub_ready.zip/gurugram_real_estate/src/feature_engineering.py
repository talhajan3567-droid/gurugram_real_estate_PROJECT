"""Feature-engineering utilities."""

import pandas as pd


def add_price_per_sqft(
    df: pd.DataFrame,
    price_col: str = "price",
    area_col: str = "area",
) -> pd.DataFrame:
    """Add price_per_sqft when price and area columns are available."""
    result = df.copy()
    if price_col in result.columns and area_col in result.columns:
        area = pd.to_numeric(result[area_col], errors="coerce")
        price = pd.to_numeric(result[price_col], errors="coerce")
        result["price_per_sqft"] = price.div(area.where(area > 0))
    return result
