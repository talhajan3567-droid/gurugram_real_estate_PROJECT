import pandas as pd

from src.data_cleaning import basic_cleaning


def test_basic_cleaning_normalizes_columns_and_removes_duplicates():
    df = pd.DataFrame({
        "Property Name": ["A", "A"],
        "Price": [100, 100],
    })

    result = basic_cleaning(df)

    assert list(result.columns) == ["property_name", "price"]
    assert len(result) == 1
