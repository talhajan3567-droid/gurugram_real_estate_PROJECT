# 🏠 Gurugram Real Estate Analysis

An end-to-end **Exploratory Data Analysis (EDA)** project for analyzing the Gurugram (Gurgaon) real-estate market using Python.

The project focuses on data cleaning, feature engineering, exploratory analysis, visualization, and extracting actionable market insights.

## 🎯 Objectives

- Understand property-price patterns
- Analyze price by location and property characteristics
- Identify high-value and budget-friendly areas
- Explore relationships between property size, bedrooms, bathrooms, and price
- Detect missing values, duplicates, and unusual records
- Produce clear visualizations and business-oriented insights

## 🧰 Tech Stack

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook

## 📁 Project Structure

```text
gurugram_real_estate/
│
├── README.md
├── requirements.txt
├── .gitignore
├── LICENSE
│
├── data/
│   ├── raw/
│   │   └── .gitkeep
│   └── processed/
│       └── .gitkeep
│
├── notebooks/
│   ├── 01_data_loading_and_cleaning.ipynb
│   ├── 02_exploratory_data_analysis.ipynb
│   └── 03_insights_and_visualization.ipynb
│
├── src/
│   ├── __init__.py
│   ├── data_cleaning.py
│   ├── feature_engineering.py
│   └── visualization.py
│
├── reports/
│   ├── figures/
│   │   └── .gitkeep
│   └── final_report.md
│
└── tests/
    └── test_data_cleaning.py
```

## 🔄 Analytical Workflow

```text
Raw Dataset
    ↓
Data Loading
    ↓
Data Quality Check
    ↓
Data Cleaning
    ↓
Feature Engineering
    ↓
Exploratory Data Analysis
    ↓
Visualization
    ↓
Insights
    ↓
Business Recommendations
```

## 📊 Key Analysis Areas

### Location Analysis
- Number of properties by locality
- Average property price by locality
- Price-per-square-foot comparison
- Most expensive and affordable locations

### Property Analysis
- Bedroom distribution
- Bathroom distribution
- Property-size distribution
- Relationship between size and price
- Relationship between bedrooms and price

### Price Analysis
- Average price
- Median price
- Price distribution
- Price per square foot
- Outlier detection

## 💡 Example Business Questions

1. Which Gurugram localities have the highest average property prices?
2. Which areas offer relatively affordable properties?
3. Does property size strongly influence price?
4. How does the number of bedrooms relate to property price?
5. Which localities have the highest price per square foot?
6. Are there unusual properties that significantly affect the analysis?

## 🧪 Reproducibility

### 1. Clone the repository

```bash
git clone https://github.com/talhajan3567-droid/gurugram_real_estate_PROJECT.git
cd gurugram_real_estate_PROJECT
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

macOS/Linux:

```bash
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Add the dataset

Place the original dataset inside:

```text
data/raw/
```

Do not commit private, licensed, or very large datasets unless you have permission to redistribute them.

### 5. Run the notebooks

Start Jupyter:

```bash
jupyter notebook
```

Then run the notebooks in order.

## 📈 Expected Outputs

The analysis can produce:

- Distribution plots
- Box plots
- Location comparisons
- Correlation analysis
- Price-vs-area visualizations
- Bedroom/price analysis
- Price-per-square-foot analysis

Save generated charts in:

```text
reports/figures/
```

## 🧠 Skills Demonstrated

- Data cleaning
- Missing-value treatment
- Duplicate detection
- Data-type conversion
- Feature engineering
- Descriptive statistics
- Exploratory Data Analysis
- Data visualization
- Correlation analysis
- Outlier analysis
- Business insight generation
- Git/GitHub project organization

## ⚠️ Data Disclaimer

This repository is intended for **educational and analytical purposes**. Real-estate listings can change over time, and analysis results depend on the source, quality, coverage, and date of the dataset.

## 👨‍💻 Author

**Talha Jan**

GitHub: https://github.com/talhajan3567-droid

---

⭐ If you find this project useful, consider starring the repository.
